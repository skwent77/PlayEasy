package com.prography.playeasy.MatchPage.MatchActivityRecyclerView;

public class Date {

    private int year;
    private int month;
    private int day;

}
