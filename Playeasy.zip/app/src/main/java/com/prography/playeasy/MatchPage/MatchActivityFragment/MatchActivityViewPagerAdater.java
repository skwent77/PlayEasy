package com.prography.playeasy.MatchPage.MatchActivityFragment;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class MatchActivityViewPagerAdater extends FragmentPagerAdapter {

    private ArrayList<Fragment> list = new ArrayList<>();

    public MatchActivityViewPagerAdater(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);

        list.add(new FirstFragment());
        list.add(new SecondFragment());
        list.add(new ThirdFragment());
    }

    @Override
    public Fragment getItem(int position) {
        return  list.get(position);
    }

    @Override
    public int getCount() {
        return list.size();
    }
}
