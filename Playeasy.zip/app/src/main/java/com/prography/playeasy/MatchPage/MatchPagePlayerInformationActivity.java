package com.prography.playeasy.MatchPage;


// 용병정보 매니저만 볼 수 있음
public class MatchPagePlayerInformationActivity {
}
