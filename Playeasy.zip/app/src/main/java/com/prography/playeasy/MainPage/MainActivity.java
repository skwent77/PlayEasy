package com.prography.playeasy.MainPage;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.prography.playeasy.R;

//메인 페이지
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}
