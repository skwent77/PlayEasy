package com.prography.playeasy.MyPage;

//마이페이지 개인정보 화면
public class MyPageMyInformationActivity {
}
