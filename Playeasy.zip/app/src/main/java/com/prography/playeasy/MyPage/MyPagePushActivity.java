package com.prography.playeasy.MyPage;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.prography.playeasy.R;

// 마이페이지 푸쉬알람
public class MyPagePushActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage_push);
    }
}
