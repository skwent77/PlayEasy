package com.prography.playeasy.MatchPage.MatchActivityRecyclerView;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.prography.playeasy.MatchPage.MatchPageDetailMatchInformationActivity;
import com.prography.playeasy.R;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    private ArrayList<Data> listData = new ArrayList<>();

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.matchactivityitemview,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.onBind(listData.get(position));
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public void addItems(Data data) {
        listData.add(data);
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView description;
        private TextView homeTeam;
        private TextView awayTeam;
        private TextView duration;
        private TextView location;
        private TextView homeQuota;
        private TextView awayQuota;
        private TextView fee;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            description = itemView.findViewById(R.id.matchDescription);
            homeTeam = itemView.findViewById(R.id.matchHomeTeam);
            awayTeam = itemView.findViewById(R.id.matchAwayTeam);
            duration = itemView.findViewById(R.id.matchDuration);
            location = itemView.findViewById(R.id.matchLocation);
            homeQuota = itemView.findViewById(R.id.matchHomeQuota);
            awayQuota = itemView.findViewById(R.id.matchAwayQutoa);
            fee = itemView.findViewById(R.id.fee);
        }

        public void onBind(Data data) {

            description.setText(data.getDescription());
            homeTeam.setText(String.valueOf(data.getHomeTeam()));
            awayTeam.setText(String.valueOf(data.getAwayTeam()));
            location.setText(String.valueOf(data.getLocation()));
            duration.setText(String.valueOf(data.getDuration()));
            homeQuota.setText(String.valueOf(data.getHomeQuota()));
            awayQuota.setText(String.valueOf(data.getAwayQuota()));
            fee.setText(String.valueOf(data.getFee()));

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent matchDetailIntent = new Intent(itemView.getContext(), MatchPageDetailMatchInformationActivity.class);
                    itemView.getContext().startActivity(matchDetailIntent);
                }
            });
        }
    }

}

