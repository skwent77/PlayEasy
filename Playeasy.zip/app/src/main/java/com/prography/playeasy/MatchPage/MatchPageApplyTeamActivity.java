package com.prography.playeasy.MatchPage;

//매치 신청 한 팀 보기
public class MatchPageApplyTeamActivity {
}
