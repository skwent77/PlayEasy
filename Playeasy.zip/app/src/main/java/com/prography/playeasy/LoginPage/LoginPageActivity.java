package com.prography.playeasy.LoginPage;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.kakao.auth.ApiErrorCode;
import com.kakao.auth.ApiResponseCallback;
import com.kakao.auth.AuthService;
import com.kakao.auth.ISessionCallback;
import com.kakao.auth.Session;
import com.kakao.auth.network.response.AccessTokenInfoResponse;
import com.kakao.network.ErrorResult;
import com.kakao.usermgmt.LoginButton;
import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;
import com.kakao.usermgmt.callback.MeV2ResponseCallback;
import com.kakao.usermgmt.response.MeV2Response;
import com.kakao.util.exception.KakaoException;
import com.prography.playeasy.R;
// 로그인 페이지
public class LoginPageActivity extends Activity {
    private TextView simpleInstruction;
    private  LoginButton  kakaoLoginButton;
    private Button logout_btn;
    private final String TAG = getClass().getSimpleName();


    TextView user_nickname,user_email;
    // 세션 콜백 구현 이름이 없는 인스턴스
    private ISessionCallback sessionCallback = new ISessionCallback() {
        @Override
        public void onSessionOpened() {
            Log.i("KAKAO_SESSION", "로그인 성공");
            UserManagement.getInstance().me(new MeV2ResponseCallback(){
                @Override
                public void onFailure(ErrorResult errorResult){
                    //로그인에 실패했을 때. 인터넷 연결이 불안정한 경우도 여기
                    int result=errorResult.getErrorCode();
                    if(result== ApiErrorCode.CLIENT_ERROR_CODE){
                        Toast.makeText(getApplicationContext(),"네트워크 연결이 불안정합니다", Toast.LENGTH_LONG).show();
                        finish();

                    }else{
                        Toast.makeText(getApplicationContext(),"로그인 도중 오류가 발생했다", Toast.LENGTH_LONG).show();
                    }
                }
                @Override
                public void onSessionClosed(ErrorResult errorResult) {
//로그인 도중 세션이 비정상적인 이유로 닫혔을 때
                }

                @Override
                public void onSuccess(MeV2Response result) {
//로그인에 성공했을 때 https://m.blog.naver.com/PostView.nhn?blogId=woo171tm&logNo=221461720960&proxyReferer=https:%2F%2Fwww.google.com%2F
//                    Intent intent=new Intent(getApplicationContext(),LoginPageActivity.class);
                    AuthService.getInstance()
                            .requestAccessTokenInfo(new ApiResponseCallback<AccessTokenInfoResponse>() {
                                @Override
                                public void onSessionClosed(ErrorResult errorResult) {
                                    Log.e("KAKAO_API", "세션이 닫혀 있음: " + errorResult);
                                }

                                @Override
                                public void onFailure(ErrorResult errorResult) {
                                    Log.e("KAKAO_API", "토큰 정보 요청 실패: " + errorResult);
                                }

                                @Override
                                public void onSuccess(AccessTokenInfoResponse result) {
                                    Log.i("KAKAO_API", "사용자 아이디: " + result.getUserId());
                                    Log.i("KAKAO_API", "남은 시간 (ms): " + result.getExpiresInMillis());
                                    Log.i("getAccessToken() : " , Session.getCurrentSession().getAccessToken());
                                 }
                            });
                }

            });
        }
//연결은 되어있는데 먼가 불안한 경우에도 onSessionOpened가 실행이 된다
//        private void requestLogout() {
//           // success_layout.setVisibility(View.GONE);
//            kakaoLoginButton.setVisibility(View.VISIBLE);
//            UserManagement.requestLogout(new LogoutResponseCallback() {
//                @Override
//                public void onCompleteLogout() {
//                    runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            Toast.makeText(LoginPageActivity.this, "로그아웃 성공", Toast.LENGTH_SHORT).show();
//                        }
//                    });
//                }
//            });
//        }
        @Override
        public void onSessionOpenFailed(KakaoException exception) {
            Log.e("KAKAO_SESSION", "로그인 실패", exception);

        }
    };


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage_loginpage);

        logout_btn = (Button)findViewById(R.id.logout_btn);
//        kakaoLoginButton = (com.kakao.usermgmt.LoginButton)findViewById(R.id.kakao_login_button);

//
//        user_nickname =(TextView)findViewById(R.id.user_nickname);
////        user_img =(CircleImageView) findViewById(R.id.user_img);
//        user_email =(TextView)findViewById(R.id.user_email);
        logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                if(Session.getCurrentSession().isOpened()) {
//                    requestLogout();
//                }
                UserManagement.getInstance()
                        .requestLogout(new LogoutResponseCallback() {
                            @Override
                            public void onCompleteLogout() {
                                Log.i("KAKAO_API", "로그아웃 완료");
                            }
                        });
            }
        });

        // 세션 콜백 등록
        Session.getCurrentSession().addCallback(sessionCallback);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // 세션 콜백 삭제
        Session.getCurrentSession().removeCallback(sessionCallback);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//check which request it is taht we're responding to
        // 카카오톡|스토리 간편로그인 실행 결과를 받아서 SDK로 전달
        if (Session.getCurrentSession().handleActivityResult(requestCode, resultCode, data)) {
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }


//        public void setKakaoLoginButton(ImageButton kakaoLoginButton) {
//            this.kakaoLoginButton = kakaoLoginButton;
//        }
}
