package com.prography.playeasy.MatchPage;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.prography.playeasy.R;

// 팀 검색 페이지
public class MatchPageSearchActivity extends AppCompatActivity {

    private Toolbar myToolbar;
    private MenuInflater menuInflater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matchpage_search);
        toolBarInitialize();
    }

    private void toolBarInitialize() {
        myToolbar = findViewById(R.id.matchToolBarSearch);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼, 디폴트로 true만 해도 백버튼이 생김
        actionBar.setDisplayShowTitleEnabled(false); // 제목 없애기
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.matchtoolbar_filter,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item)
    {
        Toast toast = Toast.makeText(getApplicationContext(),"", Toast.LENGTH_LONG);

        switch(item.getItemId())
        {
            case R.id.home:
                Intent searchBack = new Intent(this, MatchActivity.class);
                startActivity(searchBack);
                return true;

            case R.id.okMatch:
                Intent writeIntent = new Intent(this, MatchActivity.class);
                startActivity(writeIntent);
                break;
        }
        toast.show();
        return super.onOptionsItemSelected(item);
    }

}
