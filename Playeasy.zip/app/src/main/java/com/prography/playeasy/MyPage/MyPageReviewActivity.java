package com.prography.playeasy.MyPage;

//마이페이지 리뷰화면
public class MyPageReviewActivity {
}
