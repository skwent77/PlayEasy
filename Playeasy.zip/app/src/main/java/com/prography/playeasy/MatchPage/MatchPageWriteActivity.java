package com.prography.playeasy.MatchPage;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.prography.playeasy.R;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

// 매치 작성 페이지
public class MatchPageWriteActivity extends AppCompatActivity {

    private MaterialCalendarView materialCalendarView;
    private MenuInflater menuInflater;
    private Toolbar myToolbar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matchpage_write);

        calendarInitialize();
        toolBarInitialize();
    }

    private void calendarInitialize() {
        materialCalendarView = findViewById(R.id.matchWriteCalendarView);
    }

    private void toolBarInitialize() {
        myToolbar = findViewById(R.id.matchToolBarWrite);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼, 디폴트로 true만 해도 백버튼이 생김
        actionBar.setDisplayShowTitleEnabled(false); // 제목 없애기
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.matchtoolbar_write,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item)
    {
        Toast toast = Toast.makeText(getApplicationContext(),"", Toast.LENGTH_LONG);

        switch(item.getItemId())
        {

            case android.R.id.home:
                Intent writeBack = new Intent(this, MatchActivity.class);
                startActivity(writeBack);
                return true;

            case R.id.matchRegister:
                Intent intent = new Intent(this, MatchActivity.class);
                startActivity(intent);
                break;
        }
        toast.show();
        return super.onOptionsItemSelected(item);
    }

}
