package com.prography.playeasy.MatchPage;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.prography.playeasy.MatchPage.MatchActivityFragment.MatchActivityViewPagerAdater;
import com.prography.playeasy.MatchPage.MatchActivityRecyclerView.Data;
import com.prography.playeasy.MatchPage.MatchActivityRecyclerView.Date;
import com.prography.playeasy.MatchPage.MatchActivityRecyclerView.RecyclerAdapter;
import com.prography.playeasy.R;

import java.lang.reflect.Array;
import java.util.ArrayList;

// 매치화면
public class MatchActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private Toolbar myToolbar;
    private ViewPager viewPager;
    private MenuInflater menuInflater;
    private ArrayList<Data> arrayList;
    private LinearLayoutManager linearLayoutManager;
    private RecyclerAdapter adapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_match);

        bottomNavigationViewInitialize();
        viewPagerInitialize();
        toolBarInitialize();
        recyclerInitialize();

    }


    //리사이클러 뷰
    private void recyclerInitialize() {
        recyclerView = findViewById(R.id.matchRecyclerView);
        linearLayoutManager = new LinearLayoutManager(this);

        adapter = new RecyclerAdapter();
        arrayList = new ArrayList<>();

        arrayList.add(new Data("2020/6/6일", 11, 11, 10, 2, 0,2,1000 ));
        arrayList.add(new Data("2020/6/6일", 5, 5, 11, 2, 3,3,2000 ));

        for(int i = 0; i<2;i++){
            adapter.addItems(arrayList.get(i));
        }
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
    }



    //바텀 네비게이션
    private void bottomNavigationViewInitialize() {
        bottomNavigationView = findViewById(R.id.navigation);
    }

    //뷰 페이저 플래그먼트
    private void viewPagerInitialize() {
        viewPager = findViewById(R.id.container);
        MatchActivityViewPagerAdater viewPagerAdapter = new MatchActivityViewPagerAdater(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        viewPager.setAdapter(viewPagerAdapter);
    }

    // 툴바
    private void toolBarInitialize() {
        myToolbar = findViewById(R.id.matchToolBar);
        setSupportActionBar(myToolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 제목 없애기
    }

    //툴바 인플레이트 및 클릭
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
         menuInflater = getMenuInflater();
         menuInflater.inflate(R.menu.matchtoolbar_main,menu);
         return true;
    }
    @Override
    public boolean onOptionsItemSelected (MenuItem item)
    {
        Toast toast = Toast.makeText(getApplicationContext(),"", Toast.LENGTH_LONG);

        switch(item.getItemId())
        {
            case R.id.searchMatch:
                Intent searchIntent = new Intent(this, MatchPageSearchActivity.class);
                startActivity(searchIntent);

            case R.id.writeMatch:
                Intent writeIntent = new Intent(this, MatchPageWriteActivity.class);
                startActivity(writeIntent);
                break;
        }
        toast.show();
        return super.onOptionsItemSelected(item);
    }



}
