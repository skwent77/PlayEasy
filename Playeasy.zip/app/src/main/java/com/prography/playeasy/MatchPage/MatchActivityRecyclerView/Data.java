package com.prography.playeasy.MatchPage.MatchActivityRecyclerView;

import android.os.Parcel;
import android.os.Parcelable;

public class Data implements Parcelable{

    private String description;
    private int homeTeam;
    private int awayTeam;
    private int location;
    private int duration;
    private int homeQuota;
    private int awayQuota;
    private int fee;

    @Override
    public String toString() {
        return "Data{" +
                "description='" + description + '\'' +
                ", homeTeam=" + homeTeam +
                ", awayTeam=" + awayTeam +
                ", location=" + location +
                ", duration=" + duration +
                ", homeQuota=" + homeQuota +
                ", awayQuota=" + awayQuota +
                ", fee=" + fee +
                '}';
    }

    public Data(String description, int homeTeam, int awayTeam, int location, int duration, int homeQuota, int awayQuota, int fee) {
        this.description = description;
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.location = location;
        this.duration = duration;
        this.homeQuota = homeQuota;
        this.awayQuota = awayQuota;
        this.fee = fee;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getHomeTeam() {
        return homeTeam;
    }

    public void setHomeTeam(int homeTeam) {
        this.homeTeam = homeTeam;
    }

    public int getAwayTeam() {
        return awayTeam;
    }

    public void setAwayTeam(int awayTeam) {
        this.awayTeam = awayTeam;
    }

    public int getLocation() {
        return location;
    }

    public void setLocation(int location) {
        this.location = location;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getHomeQuota() {
        return homeQuota;
    }

    public void setHomeQuota(int homeQuota) {
        this.homeQuota = homeQuota;
    }

    public int getAwayQuota() {
        return awayQuota;
    }

    public void setAwayQuota(int awayQuota) {
        this.awayQuota = awayQuota;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public static Creator<Data> getCREATOR() {
        return CREATOR;
    }

    protected Data(Parcel in) {
        description = in.readString();
        homeTeam = in.readInt();
        awayTeam = in.readInt();
        location = in.readInt();
        duration = in.readInt();
        homeQuota = in.readInt();
        awayQuota = in.readInt();
        fee = in.readInt();
    }

    public static final Creator<Data> CREATOR = new Creator<Data>() {
        @Override
        public Data createFromParcel(Parcel in) {
            return new Data(in);
        }

        @Override
        public Data[] newArray(int size) {
            return new Data[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(description);
        dest.writeInt(homeTeam);
        dest.writeInt(awayTeam);
        dest.writeInt(location);
        dest.writeInt(duration);
        dest.writeInt(homeQuota);
        dest.writeInt(awayQuota);
        dest.writeInt(fee);
    }




}
