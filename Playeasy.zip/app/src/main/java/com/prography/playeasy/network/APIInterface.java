package com.prography.playeasy.network;
import retrofit2.Call;
public interface APIInterface {

//defining endpoints
//create customAdapter for binding data

}
