package com.prography.playeasy.MyPage.MyPageReviewRecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.prography.playeasy.MatchPage.MatchActivityRecyclerView.Data;
import com.prography.playeasy.R;

import java.util.ArrayList;

public class MyPageRecyclerAdapter extends RecyclerView.Adapter<MyPageRecyclerAdapter.MyViewHolder> {
    private ArrayList<Data> reviewData = new ArrayList<>();

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.mypagereviewactivityitemview,parent,false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.onBind(reviewData.get(position));
    }

    @Override
    public int getItemCount() {
        return reviewData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }

        public void onBind(Data position){

        }

    }
}
