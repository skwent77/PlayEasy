package com.prography.playeasy.MatchPage;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.prography.playeasy.R;

// 매치화면 상세보기 매니저만 볼 수 있음
public class MatchPageDetailMatchInformationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actitvity_matchpagedetailmatchinformation);
    }
}
