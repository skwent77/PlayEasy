package com.prography.playeasy.MyPage.MyPageReviewRecyclerView;

public class ReviewData {
}
